
//> using scala 3.7.2
//> using options -Xfatal-warnings -deprecation -feature -source:future -language:adhocExtensions
//> using test.dep "org.scalacheck::scalacheck:1.18.1"
