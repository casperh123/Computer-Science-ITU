```
cwk ywk date  topic (reading)
-----------------------------------------------------------------------------------------
 01  35 26/08 Intro (ch. 1-2)
 02  36 02/09 Algebraic Data Types, list (ch. 3)
 03  37 09/09 Partial Computations, option (ch. 4), first homework for exam qualification
 04  38 16/09 Laziness, lazy-list (ch. 5)
 05  39 23/09 State monad, state (ch. 6)
 06  40 30/09 Property-based testing (slides)
 07  41 07/10 Property-based testing API, prop (ch. 8)
 --  42 --/-- Fall break, no class ------------------------------------------------------
 08  43 21/10 Parser Combinators, parsers (ch. 9)
 09  44 28/10 Functional Design: Monad, monoid (ch. 10-11)
 10  45 04/11 Probabilistic Programming (slides)
 11  46 11/11 Language Semantics and Interpretations (paper)
 12  47 18/11 Reinforcement Learning Example (mini project, 2 weeks)
 13  48 25/11 Reinforcement Learning Example (mini project, 2 weeks, no lectures)
 14  49 02/12 Lenses (papers, see reading list) [or we do some other topic?]
--.  -- 05/01 Ordinary Exam - on premises Mon, 5 Jan 2026, 09:00 - 13:00
-----------------------------------------------------------------------------------------
```
